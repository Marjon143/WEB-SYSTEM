$(document).ready(function () {
    to_Navigation();
    to_dashboard();
});

function to_dashboard(){
    $.post("pages/home/home.php", {}, function (data) {
        console.log(data)
        $("#pages").html(data);
            
        });

}
function to_Navigation(){
    $.post("navigation/nav.php", {}, function (data) {
        $("#nav").html(data);
            
        });

}
