<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/about.css">
    <title>Document</title>
</head>
<body>
    <div class="bg">
        <img src="image/bg.jpg" alt="">
        <div class="Ellipse3">
            <img src="image/tan.png" alt="">
        </div>
        <p>I’m Kristan Rey M.  Flores, 21yrs old from  Camp Philips Manolo Fortich</br>
         Bukidnon studied at Northern Bukidnon State College, Taking Bachelor of Science Information Technology.</p>

         <h1>EDUCATION
            <li>Plantation Elementary School</li>
            <li>Alae National Highschool</li>
            <li>Northern Bukidnon State College</li>
         </h1>

         <h2>SOFTWARE SKILLS
            <li>Adobe Lightroom</li>
            <li>Video Editing</li>
            <li>Design</li>
         </h2>

         <h3>DESIGN SKILLS
            <li>Creativity</li>
            <li>Communication</li>
            <li>Time Management</li>
         </h3>

    </div>
</body>
</html>