<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/project.css">
    <title>Document</title>
</head>
<body>
    <div class="bg">
        <img src="image/bg.jpg" alt="">
        <h1>PROJECTS</h1>
        <div class="pro">
            <img src="image/Picture2.png" alt="">
        </div>
        <p>I'm the Presenter of SYNCMINER</p>

    </div>
</body>
</html>