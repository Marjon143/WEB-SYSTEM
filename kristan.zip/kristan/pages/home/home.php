<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/home.css">
    <title>Document</title>
</head>
<body>
    <div class="bg">
        <img src="image/bg.jpg" alt="">

        <h1>HELLO EVERYONE</h1>
        <h2>KRISTAN REY</h2>
        <p class="and" >And I’m a</p>
        <p class="front">Front End Presenter</p>
        <p class="d">Determination is doing what needs to be done even when you don’t feel like doing it</p>
        <div class="rec1">
            <img src="image/tan.png" alt="">
        </div>
        <a class="f" href="https://www.facebook.com/shellamae.flores.7">
            <img src="image/fb.png" alt="">
        </a>
        <a class="t" href="https://web.telegram.org/k/#6589669798">
            <img src="image/tele.png" alt="">
        </a>
        <a class="y" href="https://l.messenger.com/l.php?u=https%3A%2F%2Fyoutube.com%2F%40algxgaming6288%3Fsi%3D-l2vxI13pkjRBkRy&h=AT1O4FKylOjoPKV9mwNICArOf7KMRssmo4n56CG7xZbb2HpSNLdy-6zOLGTJFAQci2CahGbWoKSGj4j7LhnrFfr3ePYdNUFpXvEvmYok1er26VOvRZ0sl6zmIms4WAJXLO1SIw">
            <img src="image/yt.png" alt="">
        </a>
        <a class="s" href="https://l.messenger.com/l.php?u=https%3A%2F%2Fwww.snapchat.com%2Fadd%2Falg_xgaming%3Fshare_id%3DzB4vZ6o8ydU%26locale%3Den-AU&h=AT1O4FKylOjoPKV9mwNICArOf7KMRssmo4n56CG7xZbb2HpSNLdy-6zOLGTJFAQci2CahGbWoKSGj4j7LhnrFfr3ePYdNUFpXvEvmYok1er26VOvRZ0sl6zmIms4WAJXLO1SIw">
            <img src="image/snap.png" alt="">
        </a>

    </div>
</body>
</html>