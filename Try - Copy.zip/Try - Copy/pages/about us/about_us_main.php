<div style="width: 1488px; height: 835px; position: relative; background: white">
  <div style="width: 458px; height: 177px; left: 749px; top: 30px; position: absolute; text-align: center"><span style="color: black; font-size: 36px; font-family: Inter; font-weight: 700; word-wrap: break-word">Sign up and  discover a </span><span style="color: #FF0E0E; font-size: 36px; font-family: Inter; font-weight: 700; word-wrap: break-word">new world</span><span style="color: black; font-size: 36px; font-family: Inter; font-weight: 700; word-wrap: break-word"> with us!</span></div>
  <img style="width: 64px; height: 85px; left: 1412px; top: 11px; position: absolute; mix-blend-mode: darken" src="https://via.placeholder.com/64x85" />
  <img style="width: 46px; height: 68px; left: 1329px; top: 20px; position: absolute" src="https://via.placeholder.com/46x68" />
  <div style="width: 36px; height: 26px; left: 1375px; top: 41px; position: absolute; text-align: center; color: black; font-size: 32px; font-family: Fredoka One; font-weight: 400; word-wrap: break-word">X</div>
  <div style="width: 744px; height: 835px; left: 0px; top: 0px; position: absolute; background: black"></div>
  <div style="width: 744px; height: 835px; left: 0px; top: 0px; position: absolute; background: black"></div>
  <div style="width: 744px; height: 835px; left: 0px; top: 0px; position: absolute; background: black"></div>
  <div style="width: 218px; height: 51px; left: 511px; top: 23px; position: absolute"><span style="color: white; font-size: 40px; font-family: Montserrat; font-weight: 700; word-wrap: break-word"> </span><span style="color: #E31E0E; font-size: 40px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">NEW </span><span style="color: white; font-size: 40px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">HERE?</span></div>
  <div style="width: 393px; height: 504px; left: 545px; top: 144px; position: absolute">
    <div style="width: 385px; height: 504px; left: 8px; top: 0px; position: absolute; background: #33363F; box-shadow: 4px 4px 4px; border-radius: 40px; filter: blur(4px)"></div>
    <div style="width: 385px; height: 504px; left: 8px; top: 0px; position: absolute; background: #33363F; box-shadow: 4px 4px 4px; border-radius: 40px; filter: blur(4px)"></div>
    <div style="width: 385px; height: 504px; left: 8px; top: 0px; position: absolute; background: #33363F; box-shadow: 4px 4px 4px; border-radius: 40px; filter: blur(4px)"></div>
    <div style="width: 14px; height: 13px; left: 29px; top: 396px; position: absolute; background: #EA4335"></div>
    <div style="width: 326px; height: 23px; left: 49px; top: 394px; position: absolute; color: #818181; font-size: 12px; font-family: Inter; font-weight: 400; word-wrap: break-word"> I agree to the Terms of services and  Privacy Policy Syncminer Innovators</div>
    <div style="width: 348px; height: 42px; left: 25px; top: 348px; position: absolute; background: #D1D1D1; border-radius: 10px"></div>
    <div style="width: 296px; height: 42px; left: 51px; top: 437.50px; position: absolute; background: black; box-shadow: 0px 15px 30px rgba(0, 0, 0, 0.25); border-radius: 10px"></div>
    <div style="width: 348px; height: 42px; left: 27px; top: 198px; position: absolute; background: #D1D1D1; border-radius: 10px"></div>
    <div style="width: 338px; height: 18px; left: 27px; top: 310px; position: absolute; color: black; font-size: 14px; font-family: Inter; font-weight: 400; word-wrap: break-word"> Make sure to ensure a secure and safe password</div>
    <div style="width: 161px; height: 36px; left: 110px; top: 447px; position: absolute; text-align: right; color: #E42514; font-size: 16px; font-family: Inter; font-weight: 700; word-wrap: break-word">Create an account</div>
    <div style="width: 348px; height: 42px; left: 27px; top: 265px; position: absolute; background: #D1D1D1; border-radius: 10px"></div>
    <div style="width: 138px; height: 18px; left: 61px; top: 348px; position: absolute; mix-blend-mode: overlay; color: black; font-size: 14px; font-family: Inter; font-weight: 400; word-wrap: break-word"> Confirm Password</div>
    <div style="width: 123px; height: 18px; left: 31px; top: 198px; position: absolute; mix-blend-mode: overlay; color: black; font-size: 14px; font-family: Inter; font-weight: 400; word-wrap: break-word">@Email Address<br/></div>
    <div style="width: 342px; height: 17px; left: 28px; top: 150px; position: absolute; color: white; font-size: 13px; font-family: Inter; font-weight: 400; word-wrap: break-word"> Please fill the following information in order to sign up</div>
    <div style="width: 29px; height: 26px; left: 326px; top: 344px; position: absolute">
      <img style="width: 9.67px; height: 8.67px; left: 9.67px; top: 8.67px; position: absolute" src="https://via.placeholder.com/10x9" />
      <img style="width: 23.19px; height: 15px; left: 2.90px; top: 5.50px; position: absolute" src="https://via.placeholder.com/23x15" />
      <div style="width: 19.33px; height: 17.33px; left: 6.04px; top: 2.17px; position: absolute; border: 2px #33363F solid"></div>
    </div>
    <div style="width: 20.26px; height: 20.22px; left: 36px; top: 346px; position: absolute">
      <div style="width: 12.72px; height: 8.94px; left: 3.77px; top: 0px; position: absolute; background: black"></div>
      <div style="width: 6.12px; height: 6.11px; left: 7.07px; top: 10.82px; position: absolute; background: black"></div>
      <div style="width: 20.26px; height: 12.70px; left: 0px; top: 7.53px; position: absolute; background: black"></div>
    </div>
    <div style="width: 10.14px; height: 9.31px; left: 30.90px; top: 348px; position: absolute; transform: rotate(5.57deg); transform-origin: 0 0; border: 2px white solid"></div>
    <div style="width: 237px; left: 88px; top: 14px; position: absolute; color: white; font-size: 55px; font-family: Inter; font-weight: 700; word-wrap: break-word">SIGN UP</div>
    <div style="width: 384px; height: 44px; left: 0px; top: 81px; position: absolute; text-align: center"><span style="color: #E31E0E; font-size: 16px; font-family: Inter; font-weight: 700; word-wrap: break-word">SYNC</span><span style="color: white; font-size: 16px; font-family: Inter; font-weight: 700; word-wrap: break-word">MINER INNOVATORS INFORMATION SYSTEM</span></div>
    <div style="width: 123px; height: 18px; left: 31px; top: 265px; position: absolute; mix-blend-mode: overlay; color: black; font-size: 14px; font-family: Inter; font-weight: 400; word-wrap: break-word"> Password</div>
  </div>
</div>