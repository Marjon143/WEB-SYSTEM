<div style="width: 1488px; height: 835px; position: relative; background: white">
  <div style="width: 744px; height: 835px; left: 0px; top: 0px; position: absolute; background: black"></div>
  <div style="width: 218px; height: 51px; left: 511px; top: 23px; position: absolute"><span style="color: white; font-size: 40px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">Welcome </span><span style="color: #E31E0E; font-size: 40px; font-family: Montserrat; font-weight: 700; word-wrap: break-word"> Back</span></div>
  <div style="width: 432px; height: 177px; left: 749px; top: 30px; position: absolute; text-align: center"><span style="color: black; font-size: 24px; font-family: Inter; font-weight: 700; word-wrap: break-word">Please </span><span style="color: #FF0E0E; font-size: 24px; font-family: Inter; font-weight: 700; word-wrap: break-word">Log in</span><span style="color: black; font-size: 24px; font-family: Inter; font-weight: 700; word-wrap: break-word"> using your personal information to stay connected with us.</span></div>
  <img style="width: 64px; height: 85px; left: 1410px; top: 4px; position: absolute; mix-blend-mode: darken" src="https://via.placeholder.com/64x85" />
  <img style="width: 46px; height: 68px; left: 1327px; top: 13px; position: absolute" src="https://via.placeholder.com/46x68" />
  <div style="width: 36px; height: 26px; left: 1373px; top: 34px; position: absolute; text-align: center; color: black; font-size: 32px; font-family: Fredoka One; font-weight: 400; word-wrap: break-word">X</div>
  <div style="width: 385px; height: 504px; left: 551px; top: 157px; position: absolute">
    <div style="width: 385px; height: 504px; left: 0px; top: 0px; position: absolute; background: #33363F; box-shadow: 4px 4px 4px; border-radius: 40px; filter: blur(4px)"></div>
    <div style="width: 109px; height: 23px; left: 251px; top: 352px; position: absolute; text-align: right; color: black; font-size: 12px; font-family: Inter; font-weight: 400; word-wrap: break-word">Forgot Password?</div>
    <div style="width: 14px; height: 13px; left: 20px; top: 354px; position: absolute; background: #EA4335"></div>
    <div style="width: 110px; height: 23px; left: 41px; top: 360px; position: absolute; color: #818181; font-size: 12px; font-family: Inter; font-weight: 400; word-wrap: break-word">Keep me logged in<br/></div>
    <div style="width: 301px; height: 23px; left: 41px; top: 448px; position: absolute; color: #D9D9D9; font-size: 20px; font-family: Inter; font-weight: 400; word-wrap: break-word">Don’t have account?</div>
    <div style="width: 301px; height: 23px; left: 33px; top: 448px; position: absolute; text-align: right; color: #EA4335; font-size: 20px; font-family: Inter; font-weight: 700; word-wrap: break-word">Sign up</div>
    <div style="width: 296px; height: 42px; left: 43px; top: 387px; position: absolute; background: black; box-shadow: 0px 15px 30px rgba(0, 0, 0, 0.25); border-radius: 10px"></div>
    <div style="width: 72px; height: 36px; left: 146px; top: 397px; position: absolute; text-align: right; color: #E42514; font-size: 16px; font-family: Inter; font-weight: 700; word-wrap: break-word">Log in<br/></div>
    <div style="width: 348px; height: 42px; left: 19px; top: 310px; position: absolute; background: #D1D1D1; border-radius: 10px"></div>
    <div style="width: 123px; height: 18px; left: 23px; top: 314px; position: absolute; mix-blend-mode: overlay; color: black; font-size: 18px; font-family: Inter; font-weight: 400; word-wrap: break-word">Password</div>
    <div style="width: 213px; left: 105px; top: 7px; position: absolute"><span style="color: white; font-size: 60px; font-family: Inter; font-weight: 700; word-wrap: break-word">Login</span><span style="color: rgba(0, 0, 0, 0.20); font-size: 60px; font-family: Inter; font-weight: 700; word-wrap: break-word"> </span></div>
    <div style="width: 348px; height: 42px; left: 17px; top: 238px; position: absolute; background: #D1D1D1; border-radius: 10px"></div>
    <div style="width: 123px; height: 18px; left: 23px; top: 240px; position: absolute; mix-blend-mode: overlay; color: black; font-size: 18px; font-family: Inter; font-weight: 400; word-wrap: break-word">@Email Address<br/></div>
    <div style="width: 247px; height: 17px; left: 19px; top: 194px; position: absolute; color: white; font-size: 13px; font-family: Inter; font-weight: 400; word-wrap: break-word">Please enter your login details to sign in </div>
    <div style="width: 29px; height: 26px; left: 318px; top: 307px; position: absolute">
      <img style="width: 9.67px; height: 8.67px; left: 9.67px; top: 8.67px; position: absolute" src="https://via.placeholder.com/10x9" />
      <img style="width: 23.19px; height: 15px; left: 2.90px; top: 5.50px; position: absolute" src="https://via.placeholder.com/23x15" />
      <div style="width: 19.33px; height: 17.33px; left: 6.04px; top: 2.17px; position: absolute; border: 2px #33363F solid"></div>
    </div>
    < style="width: 20.26px; height: 20.22px; left: 28px; top: 307px; position: absolute">
      <div style="width: 12.72px; height: 8.94px; left: 3.77px; top: 0px; position: absolute; background: black"></div>
      <div style="width: 6.12px; height: 6.11px; left: 7.07px; top: 10.82px; position: absolute; background: black"></div>
      <div style="width: 20.26px; height: 12.70px; left: 0px; top: 7.53px; position: absolute; background: black"></div>
    <div style="width: 10.14px; height: 9.31px; left: 21.90px; top: 360px; position: absolute; transform: rotate(5.57deg); transform-origin: 0 0; border: 2px white solid"></div>
    <div style="width: 331px; height: 44px; left: 23px; top: 87px; position: absolute; text-align: center"><span style="color: #E31E0E; font-size: 14px; font-family: Inter; font-weight: 700; word-wrap: break-word">SYNC</span><span style="color: white; font-size: 14px; font-family: Inter; font-weight: 700; word-wrap: break-word">MINER INNOVATORS<br/> INFORMATION SYSTEM</span></div>
  </div>
</div>

