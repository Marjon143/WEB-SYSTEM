<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/contact.css">
    <title>Document</title>
</head>
<body>
    <h1>CONTACT ME</h1>
    <a class="rec1" href="estahanjacobjay@gmail.com">
        <img src="image/mail.jpg" alt="">
    </a>
    <p class="email" >Email: estahanjacobjay@gmail.com</p>

    <a class="rec2" href="https://www.facebook.com/jacobjay.estahan.1?mibextid=rS40aB7S9Ucbxw6v">
        <img src="image/fb.jpg" alt="">
    </a>
    <p class="facebook">jacob jay anlagan estahan</p>

    <a  class="rec3" href="">
        <img src="image/contacts.jpg" alt="">
    </a>
    <p class="contacts">Phone Number: 09758386017</p>

    <a class="rec4" href="https://www.tiktok.com/@jacobjayestahan?_t=8i2rpDMfGP2&_r=1">
        <img src="image/tiktok.jpg" alt="">
    </a>
    <p class="tiktok">@jaconjayestahan</p>

    <a class="rec5" href="https://instagram.com/jacobjayestahan?igshid=OGQ5ZDc2ODk2ZA==">
        <img src="image/insta.jpg" alt="">
    </a>
    <p class="instagram">@jacobjayestahan</p>

</body>
</html>