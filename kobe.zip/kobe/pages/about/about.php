<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/about.css">
    <title>Document</title>
</head>
<body>
    <h1>ABOUT ME</h1>
    <p>Hello, I'm Jacob Jay A. Estahan, currently pursuing a Bachelor of Science in Information Technology<br/>
    at Northern Bukidnon State College. Residing in Sankanan, Manolo fortich, Bukidnon at 22 years old. I<br/>
    thrive on the intersection of technology and creativity, often immersing myself in coding projects and<br/>
    expressing my imagination through digital art. When I'm not in front of a screen,<br/>
    I'm out exploring the outdoors, capturing moments through my lens as a budding photographer.<br/>
    Overall, I'm someone who values growth, connection, and the endless possibilities life offers.</p>
    <h2>SKILLS
        <li>MOTORCYCLE MECHANIC</li>
        <li>DRIVER</li>
        <li>ASSEMBLING & DISASSEMBLING CPU</li>
    </h2>
    <h3>HOBBIES
        <li>COOKING</li>
        <li>GUITAR</li>
        <li>SINGING</li>
        <li>DANCING</li>
    </h3>
    
</body>
</html>