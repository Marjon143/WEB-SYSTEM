<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/project.css">
    <title>Document</title>
</head>
<body>
    <h1>TAGLINE:
        <li>PRESENT WITH</li>
        <li>Confidence</li>
        <li>Succeed and Ease</li>
    </h1>
    <h2>LEARNINGS
        <li>PLAN CRITICALLY</li>
        <li>COLLABORATION WITH TEAMMATES</li>
        <li>COMMUNICATION</li>
        <li>DIGITAL LITERACY</li>
        <li>WRIITEN COMMUNICATION</li>
        <li>PUBLIC SPEAKING</li>
        <li>SELF MANAGEMENT</li>
        <li>WEB DEVELOPMENT</li>
     </h2>
</body>
</html>