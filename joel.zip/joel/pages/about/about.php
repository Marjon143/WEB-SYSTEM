<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/about.css">
    <title>Document</title>
</head>
<body>
    <p class="hi" >Hi, I am Joel Rodriguez Jr a.k.a   Jologs. I am 20 years old, 160 cm height.</br>
     I am currently residing at Zone3 Sankanan Manolo Fortich Bukidnon, I am introvert myself.</p>
     <h1>SKILLS
        <li>DANCE</li>
        <li>SING</li>
        <li>BEATBOX</li>
        <li>WATCHING ANIME</li>
        <li>WATCHING MOVIE</li>
     </h1>
</body>
</html>