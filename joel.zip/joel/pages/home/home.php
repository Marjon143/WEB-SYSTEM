<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/home.css">
    <title>Document</title>
</head>
<body>
    <div class="Ellipse1">
        <img src="image/joel.png" alt="">
    </div>
    <p class="hello">HELLO, I AM JOEL</br>
    RODRIGUEZ JR.</p>
    <p class="and">AND THIS IS MY</br>
    PORTFOLIO</p>

    <div class="ani">
        <img src="image/ani.png" alt="">
    </div>
</body>
</html>