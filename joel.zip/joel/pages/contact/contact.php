<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/contact.css">
    <title>Document</title>
</head>
<body>
    <a class="fbook" href="https://www.facebook.com/profile.php?id=100069437385408&mibextid=ZbWKwL">
        <img src="image/fb.png" alt="">
    </a>
    <p class="fb">www.facebook.com</p>

    <a class="phone" href="">
        <img src="image/phone.png" alt="">
    </a>
    <p class="phone">www.phonebook.com</p>

    <a class="mail" href="">
        <img src="image/google.png" alt="">
    </a>
    <p class="mail">www.gmail.com</p>
</body>
</html>