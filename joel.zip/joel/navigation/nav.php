<nav
    class="navbar navbar-expand-sm navbar-light bg-light"
>
    <div class="container">
        <a class="navbar-brand" href="#">PERSONAL PORTFOLIO</a>
        <button
            class="navbar-toggler d-lg-none"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#collapsibleNavId"
            aria-controls="collapsibleNavId"
            aria-expanded="false"
            aria-label="Toggle navigation"
        >
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavId">
            <ul class="navbar-nav me-auto mt-2 mt-lg-0">
                <li class="nav-item">
                    <a onclick="to_dashboard()" class="nav-link active" href="#" aria-current="page"
                        >HOME
                        <span class="visually-hidden">(current)</span></a
                    >
                </li>
                <li class="nav-item">
                    <a onclick="to_about()" class="nav-link" href="#">ABOUT ME</a>
                </li>
                <li class="nav-item">
                    <a onclick="to_contact()" class="nav-link" href="#">CONTACT ME</a>
                </li>
                <li class="nav-item">
                    <a onclick="to_project()" class="nav-link" href="#">PROJECTS</a>
                </li>
                
            </ul>
        </div>
    </div>
</nav>

<script>
    function to_about(){
    $.post("pages/about/about.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}

function to_contact(){
    $.post("pages/contact/contact.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}

function to_project(){
    $.post("pages/project/project.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
</script>
