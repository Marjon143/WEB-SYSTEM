<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/aboutme.css">
    <title>Document</title>
    
</head>
<body>

   <h1>HEYYYYYY </h1>
   <h2>IT'S YOUR GIRL</h2>
    <div class="Ellipse1">
        <img src="image/348564736_265916026011951_4618199768392568360_n (1).jpg" alt="">
    </div>
    

    <table width="700px, 700px" border="1">
        <tr>
            
            <th width="500px" height="25px" bgcolor="Pink">ABOUT ME</th>
        </tr>
        <tr>
            <td>
                <ul>
                    <li>Name :RE-ANNLYN DAHINO JAGONAL </li>
                    <li>Birth Date : JANUARY 14, 2004 </li>
                    <li>Birth Place : VISTA VILLA, SUMILAO, BUKIDNON </li>
                    <li>Hobbies: EATING, SLEEPING, BADMINTON, NATURE TRIP</li>
                    <li>Religion : CATHOLIC </li>
                    <li>Address : VISTA VILLA, SUMILAO, BUKIDNON </li>
                </ul>
            </td>
        </tr>
<tr>
            <th colspan="2" height="25px" bgcolor="Yellow">EDUCATIONAL BACKGROUND</th>
        </tr>
        <tr>
            <td colspan="2">
                <li>Elementary: Vista Villa Elementary School</li>
                <li>Junior Highschool: Holy Cross Highschool</li>
                <li>Senior Highschool: Vista Villa National High School</li>
                <li>College: Northern Bukidnon State College(on going)</li>
                <li>Course: Bachelor of Science in Information Technology</li>
            </td>
        </tr>
        <tr>
            <th colspan="2" height="25px" bgcolor="Yellow-Green">GOALS</th>
        </tr>
        <tr>
            <td colspan="2">
                <li>TO GRADUATE MY CURRENT COURSE</li>
                <li>TO WORK AS PNP USING MY IT SKILLS</li>
                <li>TO  BUY EVERYTHING I NEED </li>
            </td>
        </tr>
<tr>
            <th colspan="2" height="25px" bgcolor="Red">MOTTO IN LIFE</th>
        </tr>
        <tr>
            <td colspan="2">
                <li> "NON DESISTAS NON EXIERIS"</li>
                
            </td>
        
    </table>
    
    <button onclick="to_home()" style="cursor: pointer;" class="text-button">HOME</button>

    <script>
        function to_home() {
    $.post("pages/home/home_main.php", {}, function (data) {
     $("#contents").html(data);  
        });
        
}
    </script>
</body>
</html>