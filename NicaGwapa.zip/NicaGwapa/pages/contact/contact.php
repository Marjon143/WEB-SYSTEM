<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/contact.css">
    <title>Document</title>
</head>
<body>
<h1>CONTACT ME: </h1>
<h2>Phone Number:</h2>
<p> 09918521325</p>


<h3>Email Address:</h2>
<h4>nicadahino@gmail.com</h4>

<h5>Facebook:</h2>
<h6>NICADAHINO</h6>


     <div class="Ellipse1">
        <img src="image/348564736_265916026011951_4618199768392568360_n (1).jpg" alt="">
    </div>


    <button onclick="to_home()" style="cursor: pointer;" class="text-button">HOME</button>

<script>
    function to_home() {
$.post("pages/home/home_main.php", {}, function (data) {
 $("#contents").html(data);  
    });
    
}
</script>
</body>
</html>