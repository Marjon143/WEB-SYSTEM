<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/project.css">
  <title>Document</title> 
</head>
<body>
<h1>PROJECTS</h1>

<div class="col">
    <div class="card1">
      <img src="image/Screenshot (131).png" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">JAVA TASK MANAGEMENT SYSTEM</h5>
        <p class="card-text">GUI</p>
      </div>
    </div>
  </div>

  <div class="col">
    <div class="card2">
      <img src="image/Screenshot (129).png" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">SYNTECH INFORMATION MANAGEMENT SYSTEM</h5>
        <p class="card-text"></p>
      </div>
    </div>
  </div>

  <button onclick="to_home()" style="cursor: pointer;" class="text-button">HOME</button>

<script>
    function to_home() {
$.post("pages/home/home_main.php", {}, function (data) {
 $("#contents").html(data);  
    });
    
}
</script>



</body>
</html>