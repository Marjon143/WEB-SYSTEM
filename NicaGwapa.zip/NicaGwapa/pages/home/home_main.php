<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="assets/css/home.css">
  <title>Document</title>
</head>
<body>
  <h1>HOLAAAAAAAA</h1>
  <h1>WELCOME TO MY</h1>
  <h1>PERSONAL PORTFOLIO</h1>
  <button onclick="to_about_me()" style="cursor: pointer;" class="text-button">ABOUT ME</button>
  <button onclick="to_skills()" style="cursor: pointer;" class="text-button1">SKILLS</button>
  <button onclick="to_project()" style="cursor: pointer;" class="text-button2">PROJECTS</button>
  <button onclick="to_contact()" style="cursor: pointer;" class="text-button3">CONTACT ME</button>


  <script>
        function to_about_me() {
    $.post("pages/about_me/about_me.php", {}, function (data) {
     $("#contents").html(data);  
        });
        
}
function to_skills() {
    $.post("pages/skills/skills.php", {}, function (data) {
     $("#contents").html(data);  
        });
        
}
function to_project() {
    $.post("pages/project/project.php", {}, function (data) {
     $("#contents").html(data);  
        });
        
}
function to_contact() {
    $.post("pages/contact/contact.php", {}, function (data) {
     $("#contents").html(data);  
        });
        
}
    </script>
</body>
</html>