<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/contact.css">
    <title>Document</title>
</head>
<body>
    <a class="fb" href="https://web.facebook.com/profile.php?id=100085638926996&sk=photos">
        <img src="image/fb.jpg" alt="">
    </a>
    <h1>Raymund Macapondag</h1>

   
 

    <a href="" class="google">
        <img src="image/google.jpg" alt="">
    </a>
    <h3>raymundmacapundag113@gmail.com</h3>

    <a href="" class="num">
        <img src="image/phone.jpg" alt="">
    </a>
    <h4>09262530113</h4>
</body>
</html>