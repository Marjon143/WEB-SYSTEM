<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/home.css">
    <title>Document</title>
</head>
<body>
    <h1>Hello Everyone</h1>
    <h2>IM RAYMUND MACAPONDAG</h2>
    <p>Web Developer</p>
    <div class="Ellipse1">
        <img src="https://scontent.fmnl7-1.fna.fbcdn.net/v/t39.30808-6/402489790_306638012200827_3451913632389814961_n.jpg?_nc_cat=111&ccb=1-7&_nc_sid=efb6e6&_nc_eui2=AeHmlsLkysa8oO-xoPc1-YDjGdw5GbIipXMZ3DkZsiKlc3RkvcefgC1EFGmA4F0rcK9Dkz7Ktyxgvmxy3o80En4g&_nc_ohc=eqsugsBl6bUAX8jOaif&_nc_zt=23&_nc_ht=scontent.fmnl7-1.fna&oh=00_AfDviO3LD7lNssooM21NNOfPqcNABg3kNRIkFXBTxGk_DA&oe=657F028D" alt="">
    </div>
    <div class="rectangle1">
        <img src="image/car.png" alt="">
    </div>
    <a class="fb" href="">
        <img src="image/fb.jpg" alt="">
    </a>
    <a class="google" href="">
        <img src="image/google.jpg" alt="">
    </a>
    <a class="insta" href="">
        <img src="image/insta.jpg" alt="">
    </a>
</body>
</html>