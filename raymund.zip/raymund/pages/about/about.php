<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/about.css">
    <title>Document</title>
</head>
<body>
    <div class="Ellipse2">
        <img src="https://scontent.fmnl7-1.fna.fbcdn.net/v/t39.30808-6/402489790_306638012200827_3451913632389814961_n.jpg?_nc_cat=111&ccb=1-7&_nc_sid=efb6e6&_nc_eui2=AeHmlsLkysa8oO-xoPc1-YDjGdw5GbIipXMZ3DkZsiKlc3RkvcefgC1EFGmA4F0rcK9Dkz7Ktyxgvmxy3o80En4g&_nc_ohc=eqsugsBl6bUAX8jOaif&_nc_zt=23&_nc_ht=scontent.fmnl7-1.fna&oh=00_AfDviO3LD7lNssooM21NNOfPqcNABg3kNRIkFXBTxGk_DA&oe=657F028D" alt="">
    </div>
    <h1>EDUCATION
        <li>San Miguel Elementary School</li>
        <li>Manolo Fortich National High School</li>
        <li>Northern bukidnon State College</li>
    </h1>

    <h3>GOALS
        <li>Web Developer</li>
        <li>Freelancer</li>
        <li>IT Manager</li>
    </h3>
    <h2>HOBBIES
        <li>Gaming</li>
        <li>PC Disassembling</li>
    </h2>
    <p>My name Raymund Macapondag,  from San Miguel, Manolo Fortich Bukidnon. Studied at Northern Bukidnon State College, currently a Second year BSIT student. I’m the vice leader of Team Syntech.</p>
</body>
</html>