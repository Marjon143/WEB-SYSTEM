<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/home.css">
    <title>Document</title>
</head>
<body>
    <h1>Hellow Everyone</h1>
    <h2>CLINT HAROLD</h2>
    <p>I'm The Vice Leader of My Group</p>
    <div class="Ellipse1">
        <img src="image/p.jpg" alt="">
    </div>
    <div class="rectangle1">
        <img src="image/car.png" alt="">
    </div>
    <a class="fb" href="">
        <img src="image/fb.jpg" alt="">
    </a>
    <a class="google" href="">
        <img src="image/google.jpg" alt="">
    </a>
    <a class="insta" href="">
        <img src="image/insta.jpg" alt="">
    </a>
</body>
</html>