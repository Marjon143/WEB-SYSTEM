<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/about.css">
    <title>Document</title>
</head>
<body>
    <div class="Ellipse2">
        <img src="image/p.jpg" alt="">
    </div>
    <h1>EDUCATION
        <li>SANKANAN ELEMENTARY SCHOOL</li>
        <li>MANOLO FORTICH NATIONAL HIGHSCHOOL</li>
        <li>NORTEHRN BUKIDNON STATE COLLEG</li>
    </h1>
    <h2>HOBBIES
        <li>MOTOCROSS</li>
        <li>MOTOR SHOW</li>
    </h2>
    <p>My name Clint Harold T, Sumampong,  from Sankanan Manolo Fortich Bukidnon. Studied at Northern Bukidnon State College, currently a Second year BSIT student. I’m the vice leader of Team DEVBUGS.</p>
</body>
</html>