<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/contact.css">
    <title>Document</title>
</head>
<body>
    <a class="fb" href="https://www.facebook.com/clintharold.sumampong?mibextid=9R9pXO">
        <img src="image/fb.jpg" alt="">
    </a>
    <h1>clintharoldsumampong</h1>

    <a href="https://instagram.com/clintharoldsumampong?igshid=MzMyNGUyNmU2YQ==" class="insta">
        <img src="image/insta.jpg" alt="">
    </a>
    <h2>clintharoldsumampong</h2>

    <a href="" class="google">
        <img src="image/google.jpg" alt="">
    </a>
    <h3>sumampongclintharold@gmail.com</h3>

    <a href="" class="num">
        <img src="image/phone.jpg" alt="">
    </a>
    <h4>09750541409</h4>
</body>
</html>